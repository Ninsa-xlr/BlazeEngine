﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.UIElements;
using UnityEngine;
using UnityEngine.UIElements;
using PopupWindow = UnityEditor.PopupWindow;

[assembly: UxmlNamespacePrefix("VRC.SDKBase.Editor.Elements", "vrc")]
namespace VRC.SDKBase.Editor.Elements
{
    // --- BLAXE ENGINE SETTINGS WINDOW ---
    public class BlaxeEngineSettings : EditorWindow
    {
        private static readonly string[] TAGS = { "content_sex", "content_adult", "content_violence", "content_gore", "content_horror" };
        private static readonly string[] NAMES = { "Sexually Suggestive", "Adult Themes", "Graphic Violence", "Excessive Gore", "Extreme Horror" };

        [MenuItem("BLAXE_Engine/Settings/content warning tag´s")]
        public static void ShowWindow() => GetWindow<BlaxeEngineSettings>("Blaxe Engine Settings");

        private void OnGUI()
        {
            GUILayout.Label("BLAXE Engine - Default Content Warnings", EditorStyles.boldLabel);
            GUILayout.Space(5);
            
            for (int i = 0; i < TAGS.Length; i++)
            {
                string key = "BLAXE_TAG_" + TAGS[i];
                bool current = EditorPrefs.GetBool(key, false);
                bool next = EditorGUILayout.Toggle(NAMES[i], current);
                if (next != current) EditorPrefs.SetBool(key, next);
            }

            GUILayout.Space(10);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Select All")) SetAll(true);
            if (GUILayout.Button("Deselect All")) SetAll(false);
            GUILayout.EndHorizontal();
            
            GUILayout.Space(10);
            EditorGUILayout.HelpBox("Changes apply when the VRChat SDK window reloads or is clicked.", MessageType.Info);
        }
        private void SetAll(bool s) { foreach(var t in TAGS) EditorPrefs.SetBool("BLAXE_TAG_"+t, s); }
    }

    // --- MAIN SDK CLASS ---
    public class OptionsPopupField<T> : VisualElement
    {
        #region Child API
        protected virtual int GetOptionCount() => 0;
        protected virtual IList<T> GetOptions() => new List<T>();
        protected virtual string GetOptionName(T option) => option.ToString();
        protected virtual bool IsOptionLocked(T option) => false;
        
        // Null-safe text update
        protected virtual string GetPopupButtonText() => $"{_selectedOptions?.Count ?? 0}/{GetOptionCount()} Selected";
        
        protected virtual int GetPopupHeight() => GetOptionCount() * 26;
        #endregion

        private VisualElement _optionsContainer;
        private readonly Button _popupButton;

        // Initialize to prevent NullReferenceException
        private IList<T> _selectedOptions = new List<T>();
        public IList<T> SelectedOptions
        {
            get => _selectedOptions;
            set
            {
                var allOptions = GetOptions();

                // BLAXE Logic for Content Warnings
                if (allOptions.Count > 0 && allOptions[0] is string firstTag && firstTag.StartsWith("content_"))
                {
                    List<T> forcedByBlaxe = new List<T>();
                    foreach (var opt in allOptions)
                    {
                        if (EditorPrefs.GetBool("BLAXE_TAG_" + opt.ToString(), false))
                        {
                            forcedByBlaxe.Add(opt);
                        }
                    }
                    _selectedOptions = forcedByBlaxe;
                }
                else
                {
                    _selectedOptions = value?.ToList() ?? new List<T>();
                    var validOptions = GetOptions();
                    foreach (var option in _selectedOptions.ToList())
                    {
                        if (option == null || string.IsNullOrWhiteSpace(GetOptionName(option)) || !validOptions.Contains(option))
                        {
                            _selectedOptions.Remove(option);
                        }
                    }
                }
                
                if (_popupButton != null) _popupButton.text = GetPopupButtonText();
                UpdateOptions(ref _optionsContainer);
            }
        }
        
        private IList<T> _originalOptions = new List<T>();
        public IList<T> OriginalOptions
        {
            get => _originalOptions;
            set
            {
                _originalOptions = value?.ToList() ?? new List<T>();
                UpdateOptions(ref _optionsContainer);
            }
        }

        private bool _loading;
        public bool Loading
        {
            get => _loading;
            set
            {
                _loading = value;
                if (_popupButton != null) _popupButton.text = value ? "Loading..." : GetPopupButtonText();
            }
        }

        public EventHandler<T> OnToggleOption;
        public EventHandler<List<T>> OnPopupClosed;
        private VisualElement _popupBoundsReference;

        public new class UxmlFactory : UxmlFactory<OptionsPopupField<T>, UxmlTraits> { }
        public new class UxmlTraits : VisualElement.UxmlTraits
        {
            private readonly UxmlStringAttributeDescription _label = new() { name = "label" };
            public override void Init(VisualElement ve, IUxmlAttributes bag, CreationContext cc)
            {
                base.Init(ve, bag, cc);
                var optionsField = (OptionsPopupField<T>)ve;
                var label = _label.GetValueFromBag(bag, cc);
                var labelElement = optionsField.Q<Label>("label");
                if (labelElement != null)
                {
                    if (string.IsNullOrWhiteSpace(label)) labelElement.AddToClassList("d-none");
                    else labelElement.text = label;
                }
            }
        }

        public OptionsPopupField()
        {
            var visualTree = Resources.Load<VisualTreeAsset>("OptionsPopupField");
            if (visualTree != null) visualTree.CloneTree(this);
            
            var styleSheet = Resources.Load<StyleSheet>("OptionsPopupFieldStyles");
            if (styleSheet != null) styleSheets.Add(styleSheet);

            var dropdown = this.Q("dropdown");
            _popupButton = new Button { name = "popup-button" };
            _popupButton.text = GetPopupButtonText();

            var spacer = new VisualElement { name = "spacer" };
            var arrow = new VisualElement { name = "arrow" };
            
            _popupButton.Add(spacer);
            _popupButton.Add(arrow);
            if (dropdown != null) dropdown.Add(_popupButton);
            
            _popupButton.clicked += () =>
            {
                PopupWindow.Show(_popupButton.worldBound, new OptionsPopupContent(r =>
                {
                    _optionsContainer = new VisualElement();
                    r.Add(_optionsContainer);
                    UpdateOptions(ref _optionsContainer);
                }, new Vector2((_popupBoundsReference ?? _popupButton).worldBound.width, GetPopupHeight()), () =>
                {
                    OnPopupClosed?.Invoke(this, _selectedOptions.ToList());
                }));
            };
        }

        public OptionsPopupField(string label) : this()
        {
            var l = this.Q<Label>("label");
            if (l != null) l.text = label;
        }

        private VisualElement CreateOption(T option)
        {
            var optionElement = new VisualElement();
            optionElement.AddToClassList("row");
            optionElement.AddToClassList("option");
            optionElement.SetEnabled(!IsOptionLocked(option));
            
            var optionToggle = new Toggle { value = SelectedOptions.Contains(option) };
            optionToggle.RegisterValueChangedCallback(_ => OnToggleOption?.Invoke(this, option));
            optionElement.Add(optionToggle);
            optionElement.Add(new Label(GetOptionName(option)));

            return optionElement;
        }

        private void UpdateOptions(ref VisualElement optionContainer)
        {
            if (optionContainer == null) return;
            optionContainer.Clear();
            foreach (var option in GetOptions()) optionContainer.Add(CreateOption(option));
        }

        public void Refresh()
        {
            var allOptions = GetOptions().ToList();
            SelectedOptions = SelectedOptions?.Where(o => allOptions.Contains(o)).ToList() ?? new List<T>();
        }
    }
}