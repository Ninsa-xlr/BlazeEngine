﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine.UIElements;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using JetBrains.Annotations;
using UnityEditor;
using UnityEngine;
using VRC.Core;
using VRC.SDKBase.Editor;
using VRC.SDKBase.Editor.Api;
using VRC.SDKBase.Editor.Elements;

[assembly: InternalsVisibleTo("VRC.SDK3A.Editor")]
[assembly: InternalsVisibleTo("VRC.SDK3.Editor")]

namespace VRC.SDKBase
{
    public static class VRCCopyrightAgreement
    {
        private const int Version = 1;
        private const string AgreementCode = "content.copyright.owned";

        private const string SESSION_STATE_PREFIX = "VRCSdkControlPanel";
        private const string AGREEMENT_KEY = SESSION_STATE_PREFIX + ".CopyrightAgreement";
        private const string CONTENT_LIST_KEY = AGREEMENT_KEY + ".ContentList";

        // ===============================
        // BLAXE ENGINE SETTINGS
        // ===============================
        private const string BLAXE_PREF_KEY = "BLAXE_Engine.SkipCopyrightAgreement";

        [MenuItem("BLAXE_Engine/Settings/Skip Copyright Agreement")]
        private static void ToggleSkipAgreement()
        {
            bool current = EditorPrefs.GetBool(BLAXE_PREF_KEY, false);
            EditorPrefs.SetBool(BLAXE_PREF_KEY, !current);
        }

        [MenuItem("BLAXE_Engine/Settings/Skip Copyright Agreement", true)]
        private static bool ToggleSkipAgreementValidate()
        {
            Menu.SetChecked(
                "BLAXE_Engine/Settings/Skip Copyright Agreement",
                EditorPrefs.GetBool(BLAXE_PREF_KEY, false)
            );
            return true;
        }

        private static bool SkipAgreement =>
            EditorPrefs.GetBool(BLAXE_PREF_KEY, false);

        // ===============================
        // AGREEMENT TEXT
        // ===============================
        public static string AgreementText =>
            "i know You did not Buy it But idc";

        private static List<string> AgreedContentThisSession
        {
            get
            {
                var saved = SessionState.GetString(CONTENT_LIST_KEY, null);
                if (string.IsNullOrWhiteSpace(saved))
                    return new List<string>();

                return saved.Split(';').ToList();
            }
        }

        private static void SaveContentAgreementToSession(string contentId)
        {
            var agreed = AgreedContentThisSession;
            if (!agreed.Contains(contentId))
                agreed.Add(contentId);

            SessionState.SetString(CONTENT_LIST_KEY, string.Join(";", agreed));
        }

        // ===============================
        // AGREEMENT CHECK
        // ===============================
        internal static async Task<bool> HasAgreement(string contentId)
        {
            if (SkipAgreement)
            {
                SaveContentAgreementToSession(contentId);
                return true;
            }

            var hasSessionAgreement = AgreedContentThisSession.Contains(contentId);
            try
            {
                var result = await VRCApi.CheckContentUploadConsent(new VRCAgreementCheckRequest
                {
                    AgreementCode = AgreementCode,
                    ContentId = contentId,
                    Version = Version
                });

                return result.Agreed && hasSessionAgreement;
            }
            catch (Exception e)
            {
                Core.Logger.LogException(e);
            }

            return false;
        }

        internal static async Task<bool> Agree(string contentId)
        {
            if (SkipAgreement)
            {
                SaveContentAgreementToSession(contentId);
                return true;
            }

            try
            {
                var result = await VRCApi.ContentUploadConsent(new VRCAgreement
                {
                    AgreementCode = AgreementCode,
                    AgreementFulltext = AgreementText,
                    ContentId = contentId,
                    Version = Version
                });

                var agreed = result.ContentId == contentId &&
                             result.Version == Version &&
                             result.AgreementCode == AgreementCode;

                if (!agreed)
                    return false;

                SaveContentAgreementToSession(contentId);
                return true;
            }
            catch (ApiErrorException e)
            {
                Core.Logger.LogError(e.ErrorMessage);
            }
            catch (Exception e)
            {
                Core.Logger.LogException(e);
            }

            return false;
        }

        // ===============================
        // MAIN ENTRY POINT
        // ===============================
        [PublicAPI]
        public static async Task CheckCopyrightAgreement(
            PipelineManager pipelineManager,
            IVRCContent content)
        {
            if (string.IsNullOrWhiteSpace(pipelineManager.blueprintId))
                throw new Exception("No blueprint ID set");

            var contentId = string.IsNullOrWhiteSpace(content?.ID)
                ? pipelineManager.blueprintId
                : content.ID;

            if (SkipAgreement)
            {
                SaveContentAgreementToSession(contentId);
                return;
            }

            var hasConsent = await HasAgreement(contentId);
            if (hasConsent)
                return;

            var agreementTask = new TaskCompletionSource<bool>();

            var buildSectionBlock =
                VRCSdkControlPanel.window?.rootVisualElement?
                .Q("builder-panel")?.Q("section-3");

            if (buildSectionBlock != null)
            {
                var agreementModal = Modal.CreateAndShow(
                    "BLAXE_Engine",
                    AgreementText,
                    () => agreementTask.SetResult(true),
                    "RIP",
                    buildSectionBlock
                );

                agreementModal.OnCancel += (_, _) =>
                    agreementTask.SetResult(false);
            }
            else
            {
                agreementTask.SetResult(
                    EditorUtility.DisplayDialog(
                        "BLAXE_Engine",
                        AgreementText,
                        "OK",
                        "Cancel"
                    )
                );
            }

            await agreementTask.Task;

            if (!agreementTask.Task.Result)
                throw new OwnershipException(
                    "You must agree to the ownership agreement to upload"
                );

            if (!await Agree(contentId))
                throw new OwnershipException(
                    "Failed to agree to the ownership agreement"
                );
        }
    }
}
